#include "LidarDecode.hpp"
#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl/io/pcd_io.h>
#include <pcl_conversions/pcl_conversions.h>
#include <unistd.h>
#include <time.h>
#include <iostream>
#include <cmath>

std::string IP = "127.0.0.1";
unsigned short DIFOPPort = 7788;
unsigned short MSOPPort = 6699;
std::string Topic = "/sensing/lidar/pointcloud";
std::string FrameId = "lidar";

int main(int argc, char* argv[])
{
	if (argc >= 5)
	{
		IP = argv[1];
		MSOPPort = atoi(&*argv[2]);
		DIFOPPort = atoi(&*argv[3]);
		Topic = argv[4];
		FrameId = argv[5];
	}
	LidarInitDifopSocket(IP, DIFOPPort);
	LidarInitMsopSocket(IP, MSOPPort);
    
	pcl::PointCloud<pcl::PointXYZI>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZI>);

	ros::init(argc,argv,"load_pointCloud");
    ros::NodeHandle nh;
	ros::Publisher point_pub = nh.advertise<sensor_msgs::PointCloud2> (Topic, 1);
	ros::Rate loop_rate(60);
    while(ros::ok())
    {
		if (packetFullFlag){
			LidarDecodeMsopPkt(cloud);
			sensor_msgs::PointCloud2 pointCloud_msg;
			pcl::toROSMsg(*cloud,pointCloud_msg);		   //转成ros消息,rviz显示需要fixed_frame
			pointCloud_msg.header.frame_id=FrameId;
			point_pub.publish(pointCloud_msg);

			pointCloud.clear();	
			packetFullFlag = false;
		}
        ros::spinOnce();
		loop_rate.sleep();
    }

	return 0;
}