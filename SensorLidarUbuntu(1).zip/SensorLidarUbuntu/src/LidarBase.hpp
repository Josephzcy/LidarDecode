#pragma once
#include <unistd.h>
#include <iostream>
#include <vector>



	
#define SimOne_CHANNELS_PER_BLOCK (32)
#define SimOne_BLOCKS_PER_PKT (12)
#define SimOne_POINTS_CHANNEL_PER_SECOND (18000)
#define SimOne_BLOCKS_CHANNEL_PER_PKT (12)
#define SimOne_MSOP_ID (0xA050A55A0A05AA55)
#define SimOne_BLOCK_ID (0xEEFF)
#define SimOne_DIFOP_ID (0x555511115A00FFA5)

#define Sim_SWAP_SHORT(x) ((((x)&0xFF) << 8) | (((x)&0xFF00) >> 8))
#define Sim_SWAP_LONG(x) ((((x)&0xFF) << 24) | (((x)&0xFF00) << 8) | (((x)&0xFF0000) >> 8) | (((x)&0xFF000000) >> 24))
#define Sim_TO_RADS(x) ((x) * (M_PI) / 180)
#define Sim_RESOLUTION_5mm_DISTANCE_COEF (0.005)


typedef struct
{
  uint8_t year;
  uint8_t month;
  uint8_t day;
  uint8_t hour;
  uint8_t minute;
  uint8_t second;
  uint16_t ms;
  uint16_t us;
}
#ifdef __GNUC__
__attribute__((packed))
#endif
SimTimestamp;


typedef enum :uint16_t {
	START_FLAG = 0,
	MIDDLE_FLAG,
	END_FLAG
}FramFALG;

typedef struct
{
  uint64_t id;
  FramFALG    mPacketFlag;
  uint16_t    mPacketID;
  uint16_t  	mUndefined[4] = { 0 };;
  SimTimestamp mTimestamp;
  uint8_t		  mLidarModel = 0;								//2byte 31, 01 L16  02 L32
  uint8_t		  mHReserved[11] = { 0 };                        	//reserve 10 byte 32~42

}
#ifdef __GNUC__
__attribute__((packed))
#endif
SimMsopHeader;

typedef struct
{
  uint16_t distance;
  uint8_t intensity;
}
#ifdef __GNUC__
__attribute__((packed))
#endif
SimChannel;

typedef struct
{
  uint16_t id;
  uint16_t azimuth;
  SimChannel channels[SimOne_CHANNELS_PER_BLOCK];
}
#ifdef __GNUC__
__attribute__((packed))
#endif
SimOneMsopBlock;


typedef struct{
    SimMsopHeader header;
    SimOneMsopBlock blocks[SimOne_BLOCKS_PER_PKT];
    uint32_t index;
    uint16_t tail;
}
#ifdef __GNUC__
__attribute__((packed))
#endif
SimOneMsopPkt;


typedef struct
{
  uint8_t lidar_ip[4];
  uint8_t host_ip[4];
  uint8_t mac_addr[6];
  uint16_t local_port;
  uint16_t dest_port;
  uint16_t port3;
  uint16_t port4;
}
#ifdef __GNUC__
__attribute__((packed))
#endif
SimEthNet;

typedef struct
{
  uint16_t start_angle;
  uint16_t end_angle;
}
#ifdef __GNUC__
__attribute__((packed))
#endif
SimROV;

typedef struct
{
  uint8_t top_ver[5];
  uint8_t bottom_ver[5];
}
#ifdef __GNUC__
__attribute__((packed))
#endif
SimVersion;

typedef struct
{
  uint8_t num[6];
}
#ifdef __GNUC__
__attribute__((packed))
#endif
SimSn;



typedef struct
{
  uint8_t reserved1[10];
  uint8_t checksum;
  uint16_t manc_err1;
  uint16_t manc_err2;
  uint8_t gps_status;
  uint16_t temperature1;
  uint16_t temperature2;
  uint16_t temperature3;
  uint16_t temperature4;
  uint16_t temperature5;
  uint8_t reserved2[5];
  uint16_t cur_rpm;
  uint8_t reserved3[7];
}
#ifdef __GNUC__
__attribute__((packed))
#endif
SimDiagno;



typedef struct
{
  uint8_t device_current[3];
  uint8_t main_current[3];
  uint16_t vol_12v;
  uint16_t vol_12vm;
  uint16_t vol_5v;
  uint16_t vol_3v3;
  uint16_t vol_2v5;
  uint16_t vol_1v2;
}
#ifdef __GNUC__
__attribute__((packed))
#endif
SimStatus;


typedef struct
{
  uint8_t reserved[240];
  uint8_t coef;
  uint8_t ver;
}
#ifdef __GNUC__
__attribute__((packed))
#endif
SimOneIntensity;

typedef struct
{
  uint64_t id;
  uint16_t rpm;
  SimEthNet eth;
  SimROV fov;
  uint16_t reserved0;
  uint16_t phase_lock_angle;
  SimVersion version;
  SimOneIntensity intensity;
  SimSn sn;
  uint16_t zero_cali;
  uint8_t return_mode;
  uint16_t sw_ver;
  SimTimestamp timestamp;
  SimStatus status;
  uint8_t reserved1[11];
  SimDiagno diagno;
  uint8_t gprmc[86];
  uint8_t pitch_cali_low[96];
  uint8_t yaw_cali[96];
  uint8_t pitch_cali_high[288];
  uint8_t yaw_cali_high[288];
  uint16_t lidarRing;
  uint8_t reserved2[8];
  uint16_t tail;
}
#ifdef __GNUC__
__attribute__((packed))
#endif
SimOneDifopPkt;






