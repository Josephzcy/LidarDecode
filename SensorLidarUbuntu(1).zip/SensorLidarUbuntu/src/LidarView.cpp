#include "LidarDecode.hpp"
#include "visualization/pcl_visualizer.h"	

#include <unistd.h>
#include <time.h>
#include <iostream>
#include <cmath>

double const PI = 3.1415926;
std::string IP = "127.0.0.1";
unsigned short DIFOPPort = 7788;
unsigned short MSOPPort = 6699;

int main(int argc, char* argv[])
{
	
	if (argc >= 3)
	{
		IP = argv[1];
		MSOPPort = atoi(&*argv[2]);
		DIFOPPort = atoi(&*argv[3]);
	}
	LidarInitDifopSocket(IP, DIFOPPort);
	LidarInitMsopSocket(IP, MSOPPort);

	boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer (new pcl::visualization::PCLVisualizer ("51 Simone pointCloud"));
	pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZRGBA>);

	viewer->setBackgroundColor (0, 0, 0);
	viewer->addPointCloud<pcl::PointXYZRGBA> (cloud,"cloud");
	viewer->addCoordinateSystem (0.1);
	viewer->initCameraParameters ();
	viewer->setCameraPosition(0, 0, 50, 0, 0, 0);
	while(true)
	{   
		if (packetFullFlag){
			viewer->removeAllPointClouds();
			LidarDecodeMsopPkt(cloud);
			viewer->updatePointCloud(cloud);
			pointCloud.clear();	
			packetFullFlag=false;
		}
		viewer->spinOnce(1);
	}
	return 0;
}