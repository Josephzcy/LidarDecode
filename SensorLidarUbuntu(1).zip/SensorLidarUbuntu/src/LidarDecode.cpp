#include "LidarDecode.hpp"
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h> 
#include <thread> 

using namespace std;
int msop_sock; 
int difop_sock;
std::uint16_t ring; 
bool packetFullFlag=false;
std::vector<float>vert_angle_list_;
std::vector<float>hori_angle_list_;
std::vector<double> cos_lookup_table_;
std::vector<double> sin_lookup_table_;
std::vector<SimOneMsopPkt> pointCloud;


void lookup_table_init()
{
	cos_lookup_table_.resize(36000);
	sin_lookup_table_.resize(36000);
	for (uint16_t i = 0; i < 36000; i++){
		double rad = Sim_TO_RADS(i / 100.0f);
		cos_lookup_table_[i] = std::cos(rad);
		sin_lookup_table_[i] = std::sin(rad);
	}
}


void decodeDifopPkt(SimOneDifopPkt* pDifopData)
{
	lookup_table_init();
	if (pDifopData->id != SimOne_DIFOP_ID){
    	return ;
  	}
    int lsb, mid, msb, neg = 1;
	
	const uint8_t* p_ver_cali_low= pDifopData->pitch_cali_low;
	const uint8_t* p_ver_cali_high = pDifopData->pitch_cali_high;

	uint8_t* p_ver_cali = (uint8_t*)malloc(sizeof(pDifopData->pitch_cali_low)+sizeof(pDifopData->pitch_cali_high));  //384
	memcpy(p_ver_cali,pDifopData->pitch_cali_low,sizeof(pDifopData->pitch_cali_low));
	memcpy(p_ver_cali+sizeof(pDifopData->pitch_cali_low),pDifopData->pitch_cali_high,sizeof(pDifopData->pitch_cali_high));

	if(pDifopData->lidarRing > 0)
		ring=pDifopData->lidarRing;
    for (int i = 0; i < ring; i++){
	/* vert angle calibration data */
		lsb = p_ver_cali[i * 3];
		mid = p_ver_cali[i * 3 + 1];
		msb = p_ver_cali[i * 3 + 2];
		if (lsb == 0){
			neg = 1;
		}
		else if (lsb == 1){
			neg = -1;
		}
		// vert_angle_list_= (mid * 256 + msb) * neg * 0.1f;  // / 180 * M_PI;
		vert_angle_list_.emplace_back((mid * 256 + msb) * neg * 0.1f);  // / 180 * M_PI;

		/* horizon angle calibration data */
		const uint8_t* p_hori_cali = pDifopData->yaw_cali;
		lsb = p_hori_cali[i * 3];
		mid = p_hori_cali[i * 3 + 1];
		msb = p_hori_cali[i * 3 + 2];
		if (lsb == 0){
			neg = 1;
		}
		else if (lsb == 1){
			neg = -1;
		}
		// hori_angle_list_[i] = (mid * 256 + msb) * neg * 0.1f;
		hori_angle_list_.emplace_back((mid * 256 + msb) * neg * 0.1f);

	} 
	free(p_ver_cali);
}




void LidarInitDifopSocket(const std::string& ip, std::uint16_t port){
	difop_sock = socket(AF_INET, SOCK_DGRAM, 0);

	struct sockaddr_in sockAddr_difop;
	sockAddr_difop.sin_family = AF_INET;
	sockAddr_difop.sin_port = htons(port);
	sockAddr_difop.sin_addr.s_addr = inet_addr(ip.c_str());

	int retVal_difop = bind(difop_sock, (struct sockaddr *)&sockAddr_difop, sizeof(sockAddr_difop));
    if(retVal_difop==0)
	   	std::cout<<"difop socket bind success:"<<endl;

	struct sockaddr_in addrFrom_difop;
    unsigned int len_difop = sizeof(sockaddr_in);

	uint8_t recvBuf_Difop[1248] = {0};
	uint32_t recvLen_Difop;

	std::shared_ptr<SimOneDifopPkt> pDifopData((SimOneDifopPkt*)malloc(sizeof(SimOneDifopPkt)));

	recvLen_Difop = recvfrom(difop_sock, recvBuf_Difop, sizeof(SimOneDifopPkt), 0, (struct sockaddr *)&addrFrom_difop, &len_difop);

	if (recvLen_Difop > 0) {
		std::cout<<"difop socket receive data:"<<recvLen_Difop<<std::endl;
		memcpy(pDifopData.get(),recvBuf_Difop,sizeof(SimOneDifopPkt));
		decodeDifopPkt(pDifopData.get());
	}
  
}

void LidarInitMsopSocket(const std::string& ip, std::uint16_t port)
{
	
	msop_sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

	struct sockaddr_in sockAddr;
	sockAddr.sin_family = AF_INET;
	sockAddr.sin_port = htons(port);
	sockAddr.sin_addr.s_addr = inet_addr(ip.c_str());

	int retVal = bind(msop_sock, (struct sockaddr *)&sockAddr, sizeof(sockAddr));
	std::cout<<"retVal:"<<retVal<<std::endl;
	if(retVal==0)
	cout<< "msop bind success!" <<endl;
	
	if (retVal == 0){
		std::thread lidarReceiveDataThread(LidarReceiveThread);
		lidarReceiveDataThread.detach();
	}
}

void LidarReceiveThread()
{
	struct sockaddr_in addrFrom;
	unsigned int len = sizeof(sockaddr_in);

	
	char recvBuf_msop[1248] = {0};
	int recvLen;
	while (true)
	{
		recvLen = recvfrom(msop_sock, recvBuf_msop, sizeof(recvBuf_msop), 0, (struct sockaddr *)&addrFrom, &len);
		//std::cout<<"recvLen:"<<recvLen<<std::endl;
		std::shared_ptr<SimOneMsopPkt> pClouldData((SimOneMsopPkt*)malloc(sizeof(SimOneMsopPkt)));
		//SimOneMsopPkt* pClouldData=(SimOneMsopPkt*)malloc(sizeof(SimOneMsopPkt));

		if (recvLen > 0) 
		{
			//memcpy(pClouldData,recvBuf_msop,sizeof(SimOneMsopPkt));
			memcpy(pClouldData.get(),recvBuf_msop,sizeof(SimOneMsopPkt));

			pointCloud.emplace_back(*pClouldData);
			//cout<<"pClouldData->header.mPacketFlag:"<<pClouldData->header.mPacketFlag<<endl;
			if(pClouldData->header.mPacketFlag==END_FLAG){
				//cout<<"packet full"<<endl;
				packetFullFlag=true;

			}	
		}
	}
	
}

void LidarDecodeMsopPkt(pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud){
    uint16_t vertical_angle_size=vert_angle_list_.size();
	uint16_t cnt_block=0;
	if(vert_angle_list_.size()%SimOne_CHANNELS_PER_BLOCK==0)
	    cnt_block=vert_angle_list_.size()/SimOne_CHANNELS_PER_BLOCK;
	else
		cnt_block=vert_angle_list_.size()/SimOne_CHANNELS_PER_BLOCK+1;

	uint16_t current_cnt=0;
	
	cloud->points.clear();
	for(auto pointData:pointCloud)
	{
		for(int blk_idx = 0; blk_idx < SimOne_BLOCKS_PER_PKT; blk_idx++){
			int azimuth_blk = Sim_SWAP_SHORT(pointData.blocks[blk_idx].azimuth);
			float azimuth_channel;
			for (int channel_idx = 0; channel_idx < SimOne_CHANNELS_PER_BLOCK; channel_idx++){
				azimuth_channel = azimuth_blk;
				int distance = Sim_SWAP_SHORT( pointData.blocks[blk_idx].channels[channel_idx].distance);
				if(distance==0)
					continue;
				float distance_cali = distance * Sim_RESOLUTION_5mm_DISTANCE_COEF;
				
				int angle_horiz_ori = (int)(azimuth_channel + 36000) % 36000;
				int angle_vert = (((int)(vert_angle_list_[current_cnt*32+channel_idx]) % 36000) + 36000) % 36000;

				pcl::PointXYZRGBA point;
				point.x = distance_cali * cos_lookup_table_[angle_vert] * cos_lookup_table_[angle_horiz_ori] ;
				point.y = -distance_cali * cos_lookup_table_[angle_vert] * sin_lookup_table_[angle_horiz_ori] ;
				point.z = distance_cali * sin_lookup_table_[angle_vert] ;
				int intensity_temp= (int) pointData.blocks[blk_idx].channels[channel_idx].intensity;

				if (intensity_temp <= 33){
					point.r = 0;
					point.g = (int)(7.727 * intensity_temp);
					point.b = 255;
				}
				else if (intensity_temp > 33 && intensity_temp <= 66){
					point.r = 0;
					point.g = 255;
					point.b = (int)(255 - 7.727 * (intensity_temp - 34));
				}
				else if (intensity_temp > 66 && intensity_temp <= 100){
					point.r = (int)(7.727 * (intensity_temp-67));
					point.g = 255;
					point.b = 0;
				}
				else if (intensity_temp > 100 && intensity_temp <= 255){
					point.r = 255;
					// (100, 255] => (0, 33]
					point.g = (int)(255 - 7.727 * (intensity_temp-100)/4.697);
					point.b = 0;
				}

				point.a=255;
				cloud->points.emplace_back(point);
			}
			if(current_cnt<cnt_block)
				current_cnt++;
			if(current_cnt==cnt_block)
				current_cnt=0;
		}
	}

}

void LidarDecodeMsopPkt(pcl::PointCloud<pcl::PointXYZI>::Ptr cloud){
    uint16_t vertical_angle_size=vert_angle_list_.size();
	uint16_t cnt_block=0;
	if(vert_angle_list_.size()%SimOne_CHANNELS_PER_BLOCK==0)
	    cnt_block=vert_angle_list_.size()/SimOne_CHANNELS_PER_BLOCK;
	else
		cnt_block=vert_angle_list_.size()/SimOne_CHANNELS_PER_BLOCK+1;

	uint16_t current_cnt=0;

	cloud->points.clear();
	for(auto pointData:pointCloud)
	{
		for(int blk_idx = 0; blk_idx < SimOne_BLOCKS_PER_PKT; blk_idx++){
			int azimuth_blk = Sim_SWAP_SHORT(pointData.blocks[blk_idx].azimuth);
			float azimuth_channel;
			for (int channel_idx = 0; channel_idx < SimOne_CHANNELS_PER_BLOCK; channel_idx++){
				azimuth_channel = azimuth_blk;
				int distance = Sim_SWAP_SHORT( pointData.blocks[blk_idx].channels[channel_idx].distance);
				if(distance==0)
					continue;  //if reach the point of supplement ,go directly to the next block
				float distance_cali = distance * Sim_RESOLUTION_5mm_DISTANCE_COEF;
				
				int angle_horiz_ori = (int)(azimuth_channel + 36000) % 36000;
				int angle_vert = (((int)(vert_angle_list_[current_cnt*32+channel_idx]) % 36000) + 36000) % 36000;
				pcl::PointXYZI point;
				point.x = distance_cali * cos_lookup_table_[angle_vert] * cos_lookup_table_[angle_horiz_ori] ;
				point.y = -distance_cali * cos_lookup_table_[angle_vert] * sin_lookup_table_[angle_horiz_ori] ;
				point.z = distance_cali * sin_lookup_table_[angle_vert] ;
				point.intensity = pointData.blocks[blk_idx].channels[channel_idx].intensity / 255.f;
				cloud->points.emplace_back(point);
			}
			if(current_cnt<cnt_block)
				current_cnt++;
			if(current_cnt==cnt_block)
				current_cnt=0;

		}
	}

}
