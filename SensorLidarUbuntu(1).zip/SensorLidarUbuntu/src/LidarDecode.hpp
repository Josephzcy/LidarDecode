#pragma once
#include <unistd.h>
#include <iostream>
#include <vector>
#include "LidarBase.hpp"
#include "point_cloud.h"
#include "point_types.h"

extern std::vector<SimOneMsopPkt> pointCloud;

extern std::vector<float>vert_angle_list_;
extern std::vector<float>hori_angle_list_;
extern std::vector<double> cos_lookup_table_;
extern std::vector<double> sin_lookup_table_;
extern bool packetFullFlag;
extern uint16_t ring;


void InitSocket();
void LidarReceiveThread();

void LidarInitDifopSocket(const std::string& ip, std::uint16_t port);
void LidarInitMsopSocket(const std::string& ip, std::uint16_t port);
void LidarDecodeMsopPkt(pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud);
void LidarDecodeMsopPkt(pcl::PointCloud<pcl::PointXYZI>::Ptr cloud);