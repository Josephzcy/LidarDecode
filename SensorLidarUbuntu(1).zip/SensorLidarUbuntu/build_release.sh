#!/bin/bash
../../../3rdparty/artifactory/pcl.sh
if [ ! -d "build" ]; then
  mkdir build
fi
cd build
cmake .. -DWITH_ROS=1 -DCMAKE_BUILD_TYPE=Release -G "Unix Makefiles"
make -j8

